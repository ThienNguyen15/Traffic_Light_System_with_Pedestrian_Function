/*
 * buzzer.h
 *
 *  Created on: Nov 28, 2023
 *      Author: Le Van Phuc			- 2152241
 *      		Nguyen Quang Thien	- 2152994
 */

#ifndef INC_BUZZER_H_
#define INC_BUZZER_H_
#include "global.h"

void buzzer(int duty_cylce);

#endif /* INC_BUZZER_H_ */
