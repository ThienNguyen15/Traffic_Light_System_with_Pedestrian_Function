/*
 * fsm_normal_state.h
 *
 *  Created on: Oct 22, 2023
 *      Author: Le Van Phuc			- 2152241
 *      		Nguyen Quang Thien	- 2152994
 */

#ifndef INC_FSM_NORMAL_STATE_H_
#define INC_FSM_NORMAL_STATE_H_

void normalState(void);

void balance(int RED, int AMBER, int GREEN);

#endif /* INC_FSM_NORMAL_STATE_H_ */
