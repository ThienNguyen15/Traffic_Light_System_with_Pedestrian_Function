/*
 * button.h
 *
 *  Created on: Nov 27, 2023
 *      Author: Le Van Phuc			- 2152241
 *      		Nguyen Quang Thien	- 2152994
 */

#ifndef INC_BUTTON_H_
#define INC_BUTTON_H_

void Button_Reading(void);

int Is_Button_Pressed(int index);

#endif /* INC_BUTTON_H_ */
