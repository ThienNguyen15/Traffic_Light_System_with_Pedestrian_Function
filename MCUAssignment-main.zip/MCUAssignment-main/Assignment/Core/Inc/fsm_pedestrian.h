/*
 * fsm_pedestrian.h
 *
 *  Created on: Nov 28, 2023
 *      Author: Le Van Phuc			- 2152241
 *      		Nguyen Quang Thien	- 2152994
 */

#ifndef INC_FSM_PEDESTRIAN_H_
#define INC_FSM_PEDESTRIAN_H_

void fsm_pedestrian(void);

#endif /* INC_FSM_PEDESTRIAN_H_ */
